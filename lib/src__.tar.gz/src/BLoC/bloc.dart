


abstract class Bloc {
  void dispose();
}