

List sizeConstantsList =[
  'LASTEN',
  'NORMAL',
  'MEDIUM',
  'PERHE',
  'PANNU',
  'GLUTEENITON',

];