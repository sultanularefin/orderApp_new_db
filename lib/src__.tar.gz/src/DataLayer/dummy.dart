class Dummy {
  int id;
  String title;
  int price;
  int counter;
  String url;
  String amountPerUnit;
  String content;
  String level;
  double indicatorValue;

  Dummy(
      {this.id,
        this.title,
        this.price,
        this.counter,
        this.url,
        this.content,
        this.amountPerUnit,
        this.level,
        this.indicatorValue,
      }
      );
}