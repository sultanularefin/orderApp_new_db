

List categoryItems =[
  'PIZZA',
  'KEBAB',
  'KANA KEBAB',
  'SALAATTI',
  'HAMPURILAINEN',
  'LASTEN MENU',
  'JUOMAT'
];